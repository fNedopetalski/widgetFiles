class AnaliseValidate{

    validateInput(){
        var validateText = [];
        this.text = [];
        var validateTextFormated = "Por favor preencha os campos obrigatorios: "

        $.makeArray($("#collapseAnalise input")).forEach(element=>{
            element.classList.remove("missingInput");
        });

        if ((document.getElementById('radio-1c').checked == false) && (document.getElementById('radio-2c').checked == false)) {
            validateText.push("Tipo de pessoa");
            $("#pessoaFisica").addClass("radioError");
            $("#pessoaJuridica").addClass("radioError");
        }else{
            $("#pessoaFisica").removeClass("radioError");
            $("#pessoaJuridica").removeClass("radioError");
        }
        if ($('#valorSolicitado').val() == "") {
            validateText.push("Valor Solicitado");
            $("#valorSolicitado").addClass("missingInput");
            $("#errorValorSolicitado").html("<i class='flaticon flaticon-close icon-sm'></i>");
        }else{
            $("#errorValorSolicitado").html("");
        }

        if(document.getElementById("radio-1c").checked == true){
            const cpf = document.getElementById('cpf').value;
            if (($("#cpf").val() ==("")) || (cpf.length < 14)){
                validateText.push("cpf");
                $("#cpf").addClass("missingInput");
                $("#errorcpf").html("<i class='flaticon flaticon-close icon-sm'></i>");
            }else{
                $("#errorcpf").html("");
            }; 
        }

        if(document.getElementById("radio-2c").checked ==true){
        const cnpj = document.getElementById('cnpj').value;
        if (($("#cnpj").val() ==("")) || (cnpj.length < 18)){
            validateText.push("cnpj");
            $("#cnpj").addClass("missingInput");
            $("#errorCnpj").html("<i class='flaticon flaticon-close icon-sm'></i>");
        }else{
            $("#errorCnpj").html("");
        }; 
        } 
        
        if( $("#inscricaoEstadual").val() ==""){
            validateText.push("Inscrição Estadual");
            $("#inscricaoEstadual").addClass("missingInput");
            $("#errorInscricaoEstadual").html("<i class='flaticon flaticon-close icon-sm'></i>");
        }else{
            $("#errorInscricaoEstadual").html(""); 
        }

        if($("#matricula").val() ==""){
            validateText.push("Matricula");
            $("#matricula").addClass("missingInput");
            $("#errorMatricula").html("<i class='flaticon flaticon-close icon-sm'></i>")
        }else{
            $("#errorMatricula").html("");
        }

        let emailValido = this.validate();
        if(emailValido != false)  validateText.push(emailValido);

        const telefone = document.getElementById('telefone').value;
        if(($("#telefone").val() =="") || (telefone.length < 14)){
            validateText.push("Telefone");
            $("#telefone").addClass("missingInput");
            $("#errortelefone").html("<i class='flaticon flaticon-close icon-sm'></i>");
        }else{
            $("#errortelefone").html("");
        }
        if($("#tableAnexo td input").length > 0){
            let anexoValidado = this.validateAnexos();
            if(anexoValidado != true) validateText.push(anexoValidado);
        }else{
            validateText.push("Anexo Obrigatorio");
        }

        this.text = validateText;
        if(validateText.length != 0){
            if(validateText.length <=1){  
                validateTextFormated += validateText.join("")+".";
                this.toastMessage(validateTextFormated);
             }
             else{
                 validateTextFormated += validateText.join(", ") + "."; 
                this.toastMessage(validateTextFormated);
             } 
        }this.allCorrect();
    }

    toastMessage(text){ 
             FLUIGC.toast({
                title: 'Falha!',
                message: text,
                type: 'warning'
            });
            
    }

    validateEmail = (email) => {
        return email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    };

    validate = () => {
        let emailInalido = "";
        const email = $('#email').val();
        if (this.validateEmail(email)) {
           $("#email").removeClass("missingInput");
           $("#errorEmail").html("");
        } else {
          $("#email").addClass("missingInput");
          $("#errorEmail").html("<i class='flaticon flaticon-close icon-sm'></i>");
           emailInalido = "Email Invalido !";
            if($("#email").val() =="")emailInalido = "Email"
            else emailInalido = "Email Invalido !"
          return emailInalido;
        }
        return false;
    }

    validateAnexos(){
        let anexovazio;
            $("#tableAnexo td input").each((a,b)=>{
                if($(b).is("[base64]") ==false){
                    anexovazio = true;
                }
            })
            if(anexovazio == true){
                return "Anexo vazio";
            }else return true;
    }

    allCorrect(){
        if( this.text.length > 0 || this.validateAnexos() != true) {
            return false;
        }else{
            return true;
        }
    }
}