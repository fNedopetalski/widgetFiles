class AnaliseModel {
    constructor() {

    }

    static buscarDadosForm(id) {

        var constraintsDatsetWorkFlow = [];
        var constraints = [];
        
        constraintsDatsetWorkFlow.push(
            DatasetFactory.createConstraint("workflowProcessPK.processInstanceId", id, id, ConstraintType.SHOULD)
        )
        
        var solicitacao = DatasetService.getDataset('workflowProcess', null, constraintsDatsetWorkFlow, null).values;

        constraints.push(
            DatasetFactory.createConstraint("documentid", solicitacao[0].cardDocumentId, solicitacao[0].cardDocumentId, ConstraintType.MUST)
        )

        var solicitacoesAnalise = DatasetService.getDataset("dsAnaliseDeCredito3", null, constraints, null)

        return [solicitacoesAnalise.values, solicitacao[0].cardDocumentId];

    }

}