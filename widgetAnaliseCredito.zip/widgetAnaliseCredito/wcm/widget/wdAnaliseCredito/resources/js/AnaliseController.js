var table = new Object();
class AnaliseController {
  constructor() {
    this._view = new AnaliseView();
    this._validate = new AnaliseValidate();

    this._createListeners();
    this._createInputsMask();
    this._hideBar();
    this._getNome();
    this._getDate();
    this.initTableAnex();
    this._checkFilial();

    this._idFluig = window.location.href.split('?')

    if (this._idFluig[1] != '') {
      this._view.carregarDadosCorrigir(AnaliseModel.buscarDadosForm(this._idFluig[1]))
    }
  }


  _createListeners() {
    $("#upload").on("click", event => {
      this._validate.validateInput();
      this._iniciaSolicitacao();
    });

    $(".exit").on("click", event => {
      if (confirm("Você tem certeza que deseja descartar essa solicitação?")) {
        window.location.assign(`/portal/CAPUL/portal_representantes/home`);
      }
    })

    $("#btnIncludeAnex").on("click", event => {
      this.addAnex();
    });

    $('input[name="radio-types"]').on("change", event => {
      this._view.validarCpfCnpj();
    });

  }



  initTableAnex() {

    table["tableAnex"] = FLUIGC.datatable('#tableAnexo', {
      dataRequest: [],
      renderContent: ['button', 'remove'],
      header: [
        { 'title': 'Arquivo' },
        { 'title': '#' }
      ], search: {
        enabled: false
      }
    }, function (err, data) {
    });
  }


  static deleteFile(el) {
    el.closest('tr').remove();
  }

  addAnex() {

    table.tableAnex.addRow(0, {
      'button': `<input type="file" onchange="AnaliseController.preparaArquivo(this)"></button>`,
      'remove': `<button type="button" class="btn btn-danger" onclick="AnaliseController.deleteFile(this)"><i class="fluigicon fluigicon-remove-circle icon-sm"></i></button>`
    });
  }

  static async preparaArquivo(element) {

    const toBase64 = file => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
    })

    for (let i = 0; i < element.files.length; i++) {
      let base64 = await toBase64(element.files[i]);
      base64 = base64.split("base64,")

      let input = $(element);

      $(element).attr(`base64`, base64[1]);
      var filename = input[0].files[i].name;
      $(element).attr(`nameFile`, filename);
    }
  }

  _loading(fn, msg = 'Por favor, aguarde...') {
    let loading = FLUIGC.loading(window, {
      textMessage: msg
    });
    loading.show();
    setTimeout(function () {
      fn();
      loading.hide();
    }, 300);
  }

  _createInputsMask() {
    $("#valorSolicitado").maskMoney({ prefix: 'R$ ', allowNegative: true, thousands: '.', decimal: ',', affixesStay: false });
  }

  _checkFilial() {
    var session = JSON.parse(sessionStorage.dados_pessoais);
    if (session[1].FILIAL == "sim") {
      $('#area').val(session[1].NOMEFILIAL);
    } else {
      $('#area').val('REPRESENTANTE');
    }
  }

  _hideBar() {
    $('#liquidHeader_295008').parent().remove();
  }

  _getNome() {
    var session = JSON.parse(sessionStorage.dados_pessoais);
    $('#nomeSolicitante').val(session[1].NOME);
  }

  _getDate() {
    var date = new Date();
    var ano = date.getFullYear();
    var mes = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1);
    var dia = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var hora = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var minutos = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var segundos = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

    var dataCompleta = `${dia}/${mes}/${ano} ${hora}:${minutos}:${segundos}`;

    $('#dataSolicitacao').val(dataCompleta);
  }

  _iniciaSolicitacao() {
    this._loading(() => {
      if (this._validate.allCorrect() != false) {
        let files = new Array();

        $.makeArray($("#tableAnexo").find("input")).forEach(el => {
          files.push(
            {
              filename: $(el).attr(`nameFile`),
              filecontent: $(el).attr(`base64`)
            }
          )
        });
        let anexos = new Array();

        for (let i = 0; i < files.length; i++) {
          anexos.push(
            {
              filename: files[i].filename,
              filecontent: files[i].filecontent,
              description: files[i].filename
            }
          )
        }
        console.log("#########################################################")
        console.log("#########################################################")
        console.log("ID Processo -> AnaliseDeCreditoIgne")
        console.log("#########################################################")
        console.log("#########################################################")
        console.log("#########################################################")
        //var fields = new Array('ac_wf_analise_de_credito', '2', '', 'Solicitação aberta pelo Portal de Representantes', 'admin', 'true', 'false', '1', JSON.stringify({ anexos }));
        var fields = new Array('AnaliseDeCreditoIgne', '5', '', 'Solicitação aberta pelo Portal de Representantes', 'admin', 'true', 'false', '1', JSON.stringify({ anexos }));
        var varConstraints = new Array();
        var session = JSON.parse(sessionStorage.dados_pessoais);
        var codigoUser = session[1].CODIGOUSER;
        var vendaRapida = $("#checkbox3-2c").is(':checked') ? 'on' : '';

        varConstraints.push(
          DatasetFactory.createConstraint("TT_A3_VALOR_SOLICITADO", $("#valorSolicitado").val(), $("#valorSolicitado").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("codigoUser", codigoUser, codigoUser, ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A4_NOME_COMPLETO", $("#nomeSolicitante").val(), $("#nomeSolicitante").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("nomeSolicitante", $("#nomeSolicitante").val(), $("#nomeSolicitante").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A7_TELEFONE", $("#telefone").val(), $("#telefone").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A8_EMAIL", $("#email").val(), $("#email").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A9_INSCRICAO_ESTADUAL", $("#inscricaoEstadual").val(), $("#inscricaoEstadual").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A6_CNPJ", $("#cnpj").val(), $("#cnpj").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A5_CPF", $("#cpf").val(), $("#cpf").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("dataSolicitacao", $("#dataSolicitacao").val(), $("#dataSolicitacao").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("unidadeArea", $("#area").val(), $("#area").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("CB_A2_VENDA_RAPIDA", vendaRapida, vendaRapida, ConstraintType.MUST),
          DatasetFactory.createConstraint("R_A1_PESSOA", $("input[id^='radio-']:checked").val(), $("input[id^='radio-']:checked").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("tipoPessoaHidden", $("input[id^='radio-']:checked").val(), $("input[id^='radio-']:checked").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("TT_A10_MATRICULA", $("#matricula").val(), $("#matricula").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("observacoes", $("#observacoes").val(), $("#observacoes").val(), ConstraintType.MUST),
        )

        var retornoDadosDataset = "";

        if (this._idFluig[1] != '' && this._idFluig[1]) {
          varConstraints.push(DatasetFactory.createConstraint("codFluig", this._idFluig[1], this._idFluig[1], ConstraintType.MUST))
          var fieldsSaveAndSend = [this._idFluig[1], "5", 'Pool:Group:ac_group_departamento_de_cadastro', "Solicitação retornada pelo Portal de Representantes", "admin", "true", "false", "1", "0"];
          retornoDadosDataset = DatasetService.getDataset("dsSaveAndSendTask", fieldsSaveAndSend, varConstraints, null);
        } else {
          retornoDadosDataset = DatasetService.getDataset("dsStartProcessWorkflowService", fields, varConstraints, null);
        }

        if (retornoDadosDataset == '' || retornoDadosDataset == null || retornoDadosDataset == undefined) {
          FLUIGC.toast({
            title: 'Falha!',
            message: 'Não foi possivel iniciar a solicitação',
            type: 'warning',
          })
        }
        if (retornoDadosDataset.values[0].msgRetorno == '') {
          FLUIGC.toast({
            title: 'Falha!',
            message: 'Não foi possivel iniciar a solicitação',
            type: 'warning',
          })
        } else {
          var iProcess = retornoDadosDataset.values[0].msgRetorno;
          $('#iProcess').val(iProcess);
        }

        setTimeout(() => {
          window.location.assign(`/portal/CAPUL/portal_representantes/home`);
        }, 2000);
        FLUIGC.toast({
          title: 'Sucesso!',
          message: `Solicitação ${$("#iProcess").val()} enviada com sucesso`,
          type: 'success'
        })

      } else {
        return;
      }
    });
  }
}