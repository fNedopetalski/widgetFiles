/**
 * Dataset para movimentar soliciações de processos no Fluig
 * @param fields - array - [0]: processInstanceId - [1]: choosedState - [2]: array de colleagueIds - [3]: comments - [4]: userId
 * [5]: completeTask - [6]: managerMode - [7]: companyId - [8]: thread
 * @param constraints - array Constraints -  campos do formulario e seus valores;
 * @param sortFields
 * @returns
 */

function createDataset(fields, constraints, sortFields) {

	log.info('--Debbug-- dsSaveAndSendTask')
	//Cria as colunas
	var dataset = DatasetBuilder.newDataset();
	dataset.addColumn("codRetorno");
	dataset.addColumn("msgRetorno");

	var processId = fields[0];
	var choosedState = fields[1];
	var colleagueIds = [fields[2]];
	var comments = fields[3];
	var userId = fields[4];
	var completeTask = (fields[5] == 'true');
	var managerMode = (fields[6] == 'true');
	var companyId = fields[7];
	var thread = fields[8];

	log.info('--Debbug-- dsSaveAndSendTask processId: ' + processId)
	log.info('--Debbug-- dsSaveAndSendTask choosedState: ' + choosedState)
	log.info('--Debbug-- dsSaveAndSendTask comments: ' + comments)
	log.info('--Debbug-- dsSaveAndSendTask userId: ' + userId)
	log.info('--Debbug-- dsSaveAndSendTask completeTask: ' + completeTask)
	log.info('--Debbug-- dsSaveAndSendTask managerMode: ' + managerMode)
	log.info('--Debbug-- dsSaveAndSendTask companyId: ' + companyId)
	log.info('--Debbug-- dsSaveAndSendTask thread: ' + thread)

	try {
		var today = new Date();
		var year = today.getFullYear();
		var month = (today.getMonth() + 1) < 10 ? '0' + (today.getMonth() + 1) : (today.getMonth() + 1);
		var day = today.getDate() < 10 ? '0' + today.getDate() : today.getDate();
		var hour = today.getHours() < 10 ? '0' + today.getHours() : today.getHours();
		var minute = today.getMinutes() < 10 ? '0' + today.getMinutes() : today.getMinutes();
		var second = today.getSeconds() < 10 ? '0' + today.getSeconds() : today.getSeconds();
		var currentHour = hour + ":" + minute + ":" + second;
		var currentDate = day + '/' + month + '/' + year;
		var currentTime = currentDate + "  " + currentHour;

		var ECMWorkflowEngine = ServiceManager.getService('ECMWorkflowEngineService');
		log.warn("--Debbug-- ECMWorkflowEngine: " + ECMWorkflowEngine);
		var serviceLocator = ECMWorkflowEngine.instantiate('com.totvs.technology.ecm.workflow.ws.ECMWorkflowEngineServiceService');
		log.warn("--Debbug-- serviceLocator: " + serviceLocator);
		var service = serviceLocator.getWorkflowEngineServicePort();
		var serviceObj = ECMWorkflowEngine.instantiate('net.java.dev.jaxb.array.ObjectFactory');
		var serviceAttArray = ECMWorkflowEngine.instantiate('com.totvs.technology.ecm.workflow.ws.ProcessAttachmentDtoArray');
		var serviceTaskArray = ECMWorkflowEngine.instantiate('com.totvs.technology.ecm.workflow.ws.ProcessTaskAppointmentDtoArray');

		//Array de colleagueIds da solicitação
		var colleague = serviceObj.createStringArray();

		if (colleagueIds.length > 0) {
			for (var y = 0; y < colleagueIds.length; y++) {
				colleague.getItem().add(colleagueIds[y]);
			}
		} else {
			colleague.getItem().add(colleagueIds);
		}

		var cardData = serviceObj.createStringArrayArray();

		if (constraints != null) {
			for (var c = 0; c < constraints.length; c++) {
				log.info('--Debbug-- dsSaveAndSendTask constraints[c].fieldName: ' + constraints[c].fieldName)
				log.info('--Debbug-- dsSaveAndSendTask constraints[c].initialValue: ' + constraints[c].initialValue)
				var campos = serviceObj.createStringArray();
				campos.getItem().add(constraints[c].fieldName);
				campos.getItem().add(constraints[c].initialValue);
				cardData.getItem().add(campos);
			}
		}

		var result2 = service.saveAndSendTask('admin', 'Flg@1020', parseInt(companyId), processId, parseInt(choosedState), colleague, comments, userId, completeTask, serviceAttArray, cardData, serviceTaskArray, managerMode, parseInt(thread));

		if (result2.getItem().size() > 0) {
			for (var a = 0; a < result2.getItem().size(); a++) {
				var result = result2.getItem().get(a);
				log.info('--Debbug-- dsSaveAndSendTask result.getItem().get(0): ' + result.getItem().get(0))
				log.info('--Debbug-- dsSaveAndSendTask result.getItem().get(1): ' + result.getItem().get(1))
				if (result.getItem().get(0) == 'iTask' || result.getItem().get(0) == 'ERROR:') {
					dataset.addRow([result.getItem().get(0), result.getItem().get(1)]);
				}
			}
		}

	} catch (erro) {
		dataset.addRow(['ERROR:', erro]);

	}

	return dataset;
}