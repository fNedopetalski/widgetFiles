class ViewSolicitacoes {
  constructor(controller) {
    this._controller = controller;
    this._tables = new Object();
    this._modals = new Object();
  }

  openModal(button) {

    var solicitacaoButtons = `
    <a href="/portal/CAPUL/portal_representantes/cadastroCliente" class="btn customSuccess btn-block">Cadastro de Cliente</a>
    <a href="/portal/CAPUL/portal_representantes/analiseCredito" class="btn customInfo btn-block">Análise de Crédito</a>
    <br/>
    <button type="button" class="btn customDanger btn-block" data-dismiss="modal">Cancelar</button>
    `;

    this._modals["modalEscolhaSolicitacao"] = FLUIGC.modal({
      title: 'Selecione a solicitação que deseja iniciar:',
      content: solicitacaoButtons,
      id: 'novaSolicitacaoModal',
      size: 'small',
      actions: [],
    }, function (err, data) {
      if (err) {
        // do error handling
      } else {
        // do something with data
      }
    });
  }

  loadTable(solicitacoes) {
    this._controller._loading(() => {
      var dicNomeProcesso = {
        "AnaliseDeCreditoIgne": "Análise de Crédito",
        "processo_de_cadastro_cliente_IGNE": "Cadastro de Cliente"
      }

      var dicStatus = {
        "0": "Em andamento",
        "1": "Cancelado",
        "2": "Finalizado"
      }

      solicitacoes.forEach(solicitacao => {
        solicitacao["startDateProcess"] = new Date(solicitacao["startDateProcess"]).toLocaleDateString();
        solicitacao["endDateProcess"] = solicitacao["endDateProcess"] != null ? new Date(solicitacao["endDateProcess"]).toLocaleDateString() : "-"

        solicitacao["status"] = dicStatus[solicitacao["status"]];
        solicitacao["processId"] = dicNomeProcesso[solicitacao["processId"]];
        solicitacao["processInstanceId"] = solicitacao["workflowProcessPK.processInstanceId"];
      })

      var that = this;
      this._tables["tableSolicitacoes"] = FLUIGC.datatable('#target', {
        dataRequest: solicitacoes.sort((a, b) => a["workflowProcessPK.processInstanceId"] - b["workflowProcessPK.processInstanceId"]),
        renderContent: ".template_solicitacoes",
        header: [
          { 'title': "numeroAtividade", display: false },
          { 'title': "regForm", display: false },
          { 'title': 'Número' },
          { 'title': 'Processo' },
          { 'title': 'Data de abertura' },
          { 'title': 'Data de finalização' },
          { 'title': 'Status' },
          { 'title': 'Ações' },
        ],
        classSelected: 'warning',
        search: {
          enabled: false,
        },
        navButtons: {
          enabled: false,
        },
      }, function (err, data) {
        if (!err) {
          $(".btnViewSolicitacao").on("click", event => {
            var btn = event.currentTarget;
            var solicitacao = $(btn).closest("tr").find(".tdNumero").text()
            var idProcesso = $(btn).closest("tr").find(".tdProcesso").text()
            var statusProcesso = $(btn).closest("tr").find(".tdStatus").text()

            that.openModalDetalhesSolicitacao(solicitacao, idProcesso, statusProcesso);
          });
          $(".btnViewCorrigir").on("click", event => {
            var btn = event.currentTarget;
            var solicitacao = $(btn).closest("tr").find(".tdNumero").text()
            var idProcesso = $(btn).closest("tr").find(".tdProcesso").text()
            var statusProcesso = $(btn).closest("tr").find(".tdStatus").text()

            that.openModalDetalhesSolicitacao(solicitacao, idProcesso, statusProcesso);
          });
        }
      });


      $('#target tbody tr').each((a, b) => {

        if (($(b).find('td')[0].innerText != '42') && ($(b).find('td')[0].innerText != '108')) {
          $(b).find('.btnViewCorrigir').prop('disabled', true)
          $(b).find('.btnViewCorrigir').parent().removeAttr('href')
        } else {
          $(b).find('.tdStatus')[0].innerText = 'Corrigir'
          if ($(b).find('td')[0].innerText == '42') {
            const anchor = $(b).find('#linkCorrecao')[0].href
            var anchorReplace = anchor.replace("cadastroCliente", "analiseCredito");
            $(b).find('#linkCorrecao')[0].href = anchorReplace;
          }
        }

      })


    });
  }

  openModalDetalhesSolicitacao(solicitacao, idProcesso, statusProcesso) {

    var that = this;

    this._controller._loading(() => {

      var dicDatasetFormulario = {
        "Análise de Crédito": "dsAnaliseDeCredito3",
        "Cadastro de Cliente": "dsFormCadastroClienteIgne"
      }

      var constraints = new Array(
        DatasetFactory.createConstraint("codFluig", solicitacao, solicitacao, ConstraintType.SHOULD)
      )
      var detalhesSolicitacao = DatasetService.getDataset(dicDatasetFormulario[idProcesso], null, constraints, null);
      var tamanhoDetalhesSolicitacao = parseInt(detalhesSolicitacao.values.length) - 1;

      this._modals["detalhesSolicitacaoModal"] = FLUIGC.modal({
        title: '',
        content: idProcesso == "Análise de Crédito" ? this.getTemplateAnaliseCredito() : this.getTemplateCadastroCliente,
        id: 'detalhesSolicitacaoModal',
        size: 'full',
        actions: [{
          'label': 'Fechar',
          'autoClose': true
        }]
      }, function (err, data) {
        if (!err) {
          Object.keys(detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]).forEach(key => {
            $("#detalhesSolicitacaoModal").find(`[id='${key}']`).val(detalhesSolicitacao.values[tamanhoDetalhesSolicitacao][key]);
          });

          if (idProcesso == "Análise de Crédito") {
            if (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["R_A1_PESSOA"] == "Juridica") {
              $("#divcpf").hide();
              $("#divcnpj").show();
              $("#radio-2c").prop("checked", true)
            } else {
              $("#divcpf").show();
              $("#divcnpj").hide();
              $("#radio-1c").prop("checked", true)
            }

            if (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["CB_A2_VENDA_RAPIDA"] == "on") {
              $("#checkbox3-2c").prop("checked", true)
            }
            if ((statusProcesso == "Finalizado") || (statusProcesso == "Cancelado")) {
              $(".divParecer").show();
              if ((detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["SL_E3_PARECER"] == "Reprovado") || (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["SL_F3_PARECER"] == "Reprovado") || (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["decisaoCadastroGerenteHidden"] == "Reprovado")) {
                $("#statusProcesso").val("Reprovado");
                $(".valorAprovacao").hide();
              } else {
                $("#statusProcesso").val("Aprovado");
                $(".valorAprovacao").show();
                var valorAprovado = detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["TT_F4_VALOR_APROVADO"]
                $("#valorAprovado").val(valorAprovado);
              }
            }

          } else {
            if (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["radio_cadastro"] == "juridico") {
              $("#divcpf").hide();
              $("#divcnpj").show();
              $("#radio-2c").prop("checked", true)
            } else {
              $("#divcpf").show();
              $("#divcnpj").hide();
              $("#radio-1c").prop("checked", true)
            }
            if (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["tipo_cadastro"] == "2") {
              $("#divCredito").show();
            }
            if ((statusProcesso == "Finalizado") || (statusProcesso == "Cancelado")) {
              $(".divParecer").show();
              if ((detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["parecer_pre_reuniao"] == "Reprovado") || (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["laisJaiclerSelectHidden"] == "reprovado_lais") || (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["parecer_reuniao"] == "Reprovado") || (detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["parecer_comite"] == "Reprovado")) {
                $("#aprovadoReprovado").val("Reprovado");
                $(".seAprovado").hide();
              } else {
                $("#aprovadoReprovado").val("Aprovado");
                var matricula = detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["matricula"];
                $("#matriculaCadastro").val(matricula);
                $(".seAprovado").show();
                var valorComite = detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["valor_comite"];
                if (valorComite == null || valorComite == undefined) {
                  $("#creditoCadastroCliente").hide();
                } else {
                  $("#creditoAprovado").val(valorComite)
                }
              }
            }

          }
          that.montaTableAnexos(detalhesSolicitacao.values[tamanhoDetalhesSolicitacao]["codFluig"]);
        }
      });
    });
  }

  montaTableAnexos(idFluig) {
    var documentIds = DatasetService.getDataset("dsGetAttachments", [idFluig], null, null);

    if (documentIds) {
      if (documentIds.values.length > 0 && documentIds.values[0].documentId != "Array com dados nao informado") {
        $("#tableAnexosPedido").append("<tbody></tbody>");
        for (var i = 1; i < documentIds.values.length; i++) {


          var constraint = new Array(
            DatasetFactory.createConstraint("documentPK.documentId", documentIds.values[i].documentId, documentIds.values[i].documentId, ConstraintType.MUST)
          )
          var datasetDescription = DatasetService.getDataset("document", null, constraint, null);

          var token = {
            key: "52ad53d1-f25e-499e-874d-3468243c3d43",
            secret: "0fa077d9-a123-4fd5-a49f-71bd71a7de253a29773b-3492-4e15-b8fa-b01a76ca4355"
          };
          var consumer = {
            key: 'acesso_GET',
            secret: 'secretAcessoGETCAPUL#'
          };

          var oauth = OAuth({
            consumer: consumer,
            signature_method: 'HMAC-SHA1',
            hash_function: function (base_string, key) {
              return CryptoJS.HmacSHA1(base_string, key).toString(CryptoJS.enc.Base64);
            },
            nonce_length: 6
          });

          var request_data = {
            url: top.WCMAPI.getServerURL() + `/api/public/2.0/documents/getDownloadURL/${documentIds.values[i].documentId}`,
            method: 'GET',
          };

          $.ajax({
            url: top.WCMAPI.getServerURL() + `/api/public/2.0/documents/getDownloadURL/${documentIds.values[i].documentId}`,
            type: "GET",
            headers: oauth.toHeader(oauth.authorize(request_data, token)),
            contentType: "application/json",
            async: false,
            success: function (data) {
              $("#tableAnexosPedido").find("tbody").append(`
                <tr>
                  <td>${datasetDescription.values[0]["documentDescription"]}</td>
                  <td>
                    <a target="_blank" href="${data.content}"><button class="btn btn-success"><i class="flaticon flaticon-file icon-sm"></i></button></a>
                  </td>
                </tr>
              `)
            },
            error: function (data, errorThrown, status) {
              $("#tableAnexosPedido").find("tbody").append(`
                <tr>
                  <td>Anexo ${i}</td>
                  <td>
                    Erro ao buscar anexo;
                  </td>
                </tr>
              `)
            }
          });
        }
      } else {
        $("#tableAnexosPedido").closest("div").append(`<div class="col-lg-12" id="containerVazioAnexos" style="text-align: center;">
        <h4>Não há anexos nessa solicitação</h4>
      </div>`)
      }
    }
  }

  getTemplateAnaliseCredito() {
    return `
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h2 class="panel-title">Solicitante</h2>
    </div>
    <div id="collapseSolicitante" class="panel-collapse collapse in">
      <div class="panel-body">
        <div class="row">
          <div class="col-md-3 form-group">
            <label for="dataSolicitacao"> Data da Solicitação:</label>
            <input readonly type="text" class="form-control" name="dataSolicitacao" id="dataSolicitacao" readonly="">
          </div>
          <div class="col-md-6 form-group">
            <label for="NomeSolicitante">Nome:</label>
            <input readonly type="text" name="nomeSolicitante" id="nomeSolicitante" class="form-control" readonly="">
          </div>
          <div class="col-md-3 form-group">
            <label for="unidadeArea">Área:</label>
            <input readonly type="text" name="unidadeArea" id="unidadeArea" class="form-control" readonly="">
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="panel panel-dados">
    <div class="panel-heading panel-titulo-dados">
      <h2 class="panel-title">Dados da Análise</h2>
    </div>
    <div id="collapseAnalise" class="panel-collapse collapse in">
      <div class="panel-body">
        <div class="row">
          <div class="col-md-6 form-group">
            <div class="custom-radio custom-radio-inline custom-radio-primary">
              <input disabled readonly type="radio" name="radio-types" value="Fisica" id="radio-1c">
              <label for="radio-1c" id="pessoaFisica">Pessoa Física</label>
            </div>
            <div class="custom-radio custom-radio-inline custom-radio-primary">
              <input disabled readonly type="radio" name="radio-types" value="Juridica" id="radio-2c">
              <label for="radio-2c" id="pessoaJuridica">Pessoa Jurídica</label>
            </div>
            <div class="custom-checkbox custom-checkbox-inline custom-checkbox-primary">
              <input disabled readonly type="checkbox" name="checkbox-types" value="Venda Rápida" id="checkbox3-2c">
              <label for="checkbox3-2c">Venda Rápida</label>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 form-group">
            <label class="control-label" for="TT_A3_VALOR_SOLICITADO">Valor Solicitado
              (Crédito):</label>
            <p id="valoerSolicitadoSimb" class="errorSimb">*</p>
            <div class="input-group">
              <div class="input-group-addon"><i class="flaticon flaticon-monetization-on icon-sm"></i></div>
              <input readonly type="text" name="TT_A3_VALOR_SOLICITADO" id="TT_A3_VALOR_SOLICITADO" class="form-control">
            </div>
          </div>
          <div class="col-md-6 form-group">
            <label for="matricula">Matricula:</label>
            <p id="matriculaSimb" class="errorSimb">*</p>
            <input readonly type="text" name="TT_A10_MATRICULA" id="TT_A10_MATRICULA" class="form-control">
            <span class="errorSpan" id="errorMatricula"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 form-group" id="divcpf" style="display:none">
            <label for="cpf">CPF:</label>
            <p id="cpfSimb" class="errorSimb">*</p>
            <input readonly type="text" name="TT_A5_CPF" id="TT_A5_CPF" class="form-control"
              onkeydown="return CadastroUtil.mascaraCpf(this, event)"
              onkeyup="return CadastroUtil.mascaraCpf(this, event)">
            <span class="errorSpan" id="errorcpf"></span>
          </div>
          <div class="col-md-6 form-group" id="divcnpj">
            <label for="cnpj">CNPJ:</label>
            <p id="cnpjSimb" class="errorSimb">*</p>
            <input readonly type="text" name="TT_A6_CNPJ" id="TT_A6_CNPJ" class="form-control">
            <span class="errorSpan" id="errorCnpj"></span>
          </div>
          <div class="col-md-6 form-group">
            <label for="inscricaoEstadual">Inscrição Estadual:</label>
            <p id="incricaoEstadualSimb" class="errorSimb">*</p>
            <input readonly type="text" name="TT_A9_INSCRICAO_ESTADUAL" id="TT_A9_INSCRICAO_ESTADUAL" class="form-control">
            <span class="errorSpan" id="errorInscricaoEstadual"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 form-group">
            <label for="email">Email:</label>
            <p id="emailSimb" class="errorSimb">*</p>
            <input readonly type="email" name="TT_A8_EMAIL" id="TT_A8_EMAIL" class="form-control">
            <span class="errorSpan" id="errorEmail"></span>
          </div>
          <div class="col-md-6 form-group">
            <label for="telefone">Telefone:</label>
            <p id="telefoneSimb" class="errorSimb">*</p>
            <input readonly type="text" name="TT_A7_TELEFONE" id="TT_A7_TELEFONE" class="form-control">
            <span class="errorSpan" id="errortelefone"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 form-group">
            <label for="observacoes">Observações:</label>
            <textarea readonly name="observacoes" class="form-control" id="observacoes" rows="5"></textarea>
            <span class="errorSpan" id="errorObservacoes"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 form-group">
            <table id="tableAnexosPedido" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Anexo</th>
                  <th>Visualizar</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
        <div class="divParecer" style="display:none">
                <div class="row">
                  <div class="col-md-4 form-group">
                    <label for="statusProcesso">Status:</label>
                    <input class="form-control" type="text" name="statusProcesso" id="statusProcesso" readonly>
                  </div>
                  <div class="col-md-6 form-group valorAprovacao">
                    <label for="valorAprovado">Crédito Aprovado:</label>
                    <input class="form-control" type="text" name="valorAprovado" id="valorAprovado" readonly>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>`
  }

  getTemplateCadastroCliente() {
    return `

    <table class="table" tablename="tableHistoricoXX" noaddbutton=true nodeletebutton=true hidden>
      <thead>
        <tr>
          <td>Indice</td>
          <td>Data</td>
          <td>Nome</td>
          <td>Painel Historico 1</td>
          <td>Painel Historico 2</td>
          <td>Painel Historico 3</td>
          <td>Painel Historico 4</td>
          <td>Valores Campos</td>
        </tr>
      </thead>
      <tbody>

        <tr id="rowPainelHistorico">
          <td><input type="text" id="indiceHistorico" name="indiceHistorico" /></td>
          <td><input type="text" id="dataHistorico" name="dataHistorico" /></td>
          <td><input type="text" id="nomeSolicitanteHistorico" name="nomeSolicitanteHistorico" /></td>
          <td><textarea name="painelHistorico1" id="painelHistorico1" cols="300" rows="100"></textarea></td>
          <td><textarea name="painelHistorico2" id="painelHistorico2" cols="300" rows="100"></textarea></td>
          <td><textarea name="painelHistorico3" id="painelHistorico3" cols="300" rows="100"></textarea></td>
          <td><textarea name="painelHistorico4" id="painelHistorico4" cols="300" rows="100"></textarea></td>
          <td><textarea name="valuesCamposHistorico" id="valuesCamposHistorico" cols="300" rows="100"></textarea></td>

        </tr>
      </tbody>
    </table>

    <div class="panel panel-primary">
	<div class="panel-heading">
		<h2 class="panel-title">Solicitante</h2>
	</div>
	<div id="collapseSolicitante" class="panel-collapse collapse in">
		<div class="panel-body">
			<div class="row">
				<div class="col-md-3 form-group">
					<label for="dataSolicitacao"> Data da Solicitação:</label>
					<input readonly type="text" class="form-control" name="dataSolicitacao" id="dataSolicitacao"
						readonly>
				</div>
				<div class="col-md-6 form-group">
					<label for="NomeSolicitante">Nome:</label>
					<input readonly type="text" name="nomeSolicitante" id="nomeSolicitante" class="form-control"
						readonly>
				</div>
				<div class="col-md-3 form-group">
					<label for="area">Área:</label>
					<input readonly type="text" name="unidadeArea" id="unidadeArea" class="form-control" readonly>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="panel panel-cadastro">
	<div class="panel-heading panel-titulo-cadastro">
		<h2 class="panel-title">Cadastro</h2>
	</div>
	<div id="collapseCadastro" class="panel-collapse collapse in">
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12 form-group">
					<label for="tipoCadastro">Selecione um Cadastro:</label>
					<p id="nomeSimb" class="errorSimb">*</p>
					<select readonly disabled id="tipo_cadastro" name="tipo_cadastro" class="form-control">
						<option value="0" selected disabled hidden>Selecione uma opção</option>
						<option value="1">Cadastro Simples</option>
						<option value="2">Cadastro Cliente</option>
						<option value="3">Cadastro Cooperado</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-md-2 form-group">
					<div class="custom-radio custom-radio-inline custom-radio-primary">
						<input disabled readonly type="radio" name="radio-types" value="fisico" id="radio-1c">
						<label for="radio-1c" id="pessoaFisica">Pessoa Física</label>
					</div>
					<div class="custom-radio custom-radio-inline custom-radio-primary">
						<input disabled readonly type="radio" name="radio-types" value="juridico" id="radio-2c">
						<label for="radio-2c" id="pessoaJuridica">Pessoa Juridica</label>
					</div>
				</div>
			</div>
			<div id="divAlert" class="alert alert-warning alert-dismissible" role="alert" style="display:none;">
			</div>

			<div class="row" id="divCredito" style="display:none">
				<div class="col-md-6 form-group">
					<label class="control-label" for="valor_credito">Valor Solicitado
						(Crédito):</label>
					<p id="valorCreditoSimb" class="errorSimb">*</p>
					<div class="input-group">
						<div class="input-group-addon"><i class="flaticon flaticon-monetization-on icon-sm"></i></div>
						<input readonly type="text" name="valor_credito" id="valor_credito" class="form-control">
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6 form-group">
					<label for="nomeCliente">Nome:</label>
					<p id="nomeSimb" class="errorSimb">*</p>
					<input readonly type="text" name="nome_completo" id="nome_completo" class="form-control">
					<span class="errorSpan" id="errorNomeCliente"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 form-group" id="divcpf" style="display:none">
					<label for="cpf">CPF:</label>
					<p id="cpfSimb" class="errorSimb">*</p>
					<input readonly type="text" name="escCPF" id="escCPF" class="form-control">
					<span class="errorSpan" id="errorcpf"></span>
				</div>
				<div class="col-md-6 form-group" id="divcnpj" style="display:none">
					<label for="cnpj">CNPJ:</label>
					<p id="cnpjSimb" class="errorSimb">*</p>
					<input readonly type="text" name="escCNPJ" id="escCNPJ" class="form-control">
					<span class="errorSpan" id="errorCnpj"></span>
				</div>
				<div class="col-md-6 form-group">
					<label for="inscricaoEstadual">Inscrição Estadual:</label>
					<p id="inscricaoEstadualSimb" class="errorSimb">*</p>
					<input readonly type="text" name="inscricao_estadual" id="inscricao_estadual" class="form-control">
					<span class="errorSpan" id="errorInscricaoEstadual"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 form-group">
					<label for="email">Email:</label>
					<p id="emailSimb" class="errorSimb">*</p>
					<input readonly type="email" name="email" id="email" class="form-control">
					<span class="errorSpan" id="errorEmail"></span>
				</div>
				<div class="col-md-6 form-group">
					<label for="telefone">Telefone:</label>
					<p id="telefoneSimb" class="errorSimb">*</p>
					<input readonly type="text" name="telefone" id="telefone" class="form-control">
					<span class="errorSpan" id="errortelefone"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 form-group">
					<label for="observacoes">Observações:</label>
					<textarea readonly name="observacoes" class="form-control" id="observacoes" rows="5"></textarea>
					<span class="errorSpan" id="errorObservacoes"></span>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 form-group">
					<table id="tableAnexosPedido" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>Anexo</th>
								<th>Visualizar</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
			<div class="divParecer" style="display:none">
                <div class="row">
                  <div class="col-md-4 form-group">
                    <label for="aprovadoReprovado">Status:</label>
                    <input class="form-control" type="text" name="aprovadoReprovado" id="aprovadoReprovado" readonly>
                  </div>
                  <div class="col-md-4 form-group seAprovado">
                    <label for="matriculaCadastro">Matricula:</label>
                    <input class="form-control" type="text" name="matriculaCadastro" id="matriculaCadastro" readonly>
                  </div>
                  <div class="col-md-4 form-group seAprovado" id="creditoCadastroCliente">
                    <label for="creditoAprovado">Crédito Aprovado:</label>
                    <input class="form-control" type="text" name="creditoAprovado" id="creditoAprovado" readonly>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>`
  }

}
