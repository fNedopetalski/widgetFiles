class ControllerSolicitacoes {
	constructor() {
		this._view = new ViewSolicitacoes(this);

		this._modalTrigger();
		this._hideBar();
		this._listarSolicitacoes();
	}

	_loading(fn, msg = 'Por favor, aguarde...') {
		let loading = FLUIGC.loading(window, {
			textMessage: msg
		});
		loading.show();
		setTimeout(function () {
			fn();
			loading.hide();
		}, 300);
	}

	_hideBar() {
		$('#liquidHeader_295008').parent().remove();
	}

	_modalTrigger() {
		$("#novaSolicitacao").on("click", event => {
			var btn = event.target;
			this._view.openModal(btn);
		})
	}

	_listarSolicitacoes() {
		this._loading(() => {
			var constraints = new Array();

			var session = JSON.parse(sessionStorage.dados_pessoais);
			var codigo = session[1].CODIGOUSER;

			constraints.push(
				DatasetFactory.createConstraint("codigoUser", codigo, codigo, ConstraintType.MUST),
				DatasetFactory.createConstraint("metadata#active", "1", "1", ConstraintType.MUST),
			)
			var userSolicitacoes = new Array();

			var solicitacoesAnalise = DatasetService.getDataset("dsAnaliseDeCredito3", null, constraints, null)
			var solicitacoesCadastro = DatasetService.getDataset("dsFormCadastroClienteIgne", null, constraints, null)

			userSolicitacoes = solicitacoesAnalise.values.concat(solicitacoesCadastro.values)

			if (userSolicitacoes) {
				if (userSolicitacoes.length > 0) {
					var constraintsDatsetWorkFlow = [];
					userSolicitacoes.forEach(process => {
						if (process.codFluig) {
							constraintsDatsetWorkFlow.push(
								DatasetFactory.createConstraint("workflowProcessPK.processInstanceId", process.codFluig, process.codFluig, ConstraintType.SHOULD)
							)
						}
					})
					var solicitacoesEncontradas = DatasetService.getDataset('workflowProcess', null, constraintsDatsetWorkFlow, null);

					solicitacoesEncontradas.values.map(a=>{						
						var solicitacao = userSolicitacoes.filter(b=>b.codFluig==a["workflowProcessPK.processInstanceId"])
						if (solicitacao.length>0) {
							solicitacao = Utils.sortByAttribute(solicitacao, 'id')
							a['numeroAtividade']=solicitacao[solicitacao.length-1].numeroAtividade
							a['regForm']=solicitacao[solicitacao.length - 1]
						} else {
							a['numeroAtividade']=''
							a['regForm']=''
						}							
					})

					this._view.loadTable(solicitacoesEncontradas.values);


				} else {
					FLUIGC.toast({
						title: "Nenhuma solicitação encontrada.",
						message: "",
						type: "warning"
					})
					this._view.loadTable([]);
				}
			} else {
				FLUIGC.toast({
					title: "Erro ao consultar processos do usuário logado.",
					message: "",
					type: "danger"
				})
				this._view.loadTable([]);
			}
		});
	}
	
}