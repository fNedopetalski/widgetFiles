class FluigFile {
  constructor() {
    throw 'Esta classe não pode ser instanciada';
  }

  /**
 * @param {String} funcao - Valor referente ao comportamento que a função irá assumir.
 * - criarPasta -> Cria uma pasta
 * - listarDocumentos -> Lista os documentos da pasta
 * - remover -> Remove um documento ou pasta
 * - alterar -> Alterar uma pasta
 * @param {String} dadosJson JSON em formato String com os dados da requisição.
 *
 * @returns {Object} Dados obtidos na resposta do ajax.
 */
  static ajaxApi(funcao, dadosJson) {
    var token = {
      key: "52ad53d1-f25e-499e-874d-3468243c3d43",
      secret: "0fa077d9-a123-4fd5-a49f-71bd71a7de253a29773b-3492-4e15-b8fa-b01a76ca4355"
    };
    var consumer = {
      key: 'acesso_GET',
      secret: 'secretAcessoGETCAPUL#'
    };

    var oauth = OAuth({
      consumer: consumer,
      signature_method: 'HMAC-SHA1',
      hash_function: function (base_string, key) {
        return CryptoJS.HmacSHA1(base_string, key).toString(CryptoJS.enc.Base64);
      },
      nonce_length: 6
    });


    const restApiEcm = 'api/public/ecm/document';
    let url;
    let metodo = 'POST';
    let assincrono = false;
    let resultado = null;

    switch (funcao) {
      case 'criarArquivo':
        url = `/${restApiEcm}/createDocument`;
        break;
      case 'upload':
        url = `/${restApiEcm}/upload`;
        break;
      case 'criarPasta':
        url = `/api/public/2.0/folderdocuments/create`;
        break;
      case 'listarDocumentos':
        url = `/${restApiEcm}/listDocument/${dadosJson}`;
        metodo = 'GET';
        break;
      case 'remover':
        url = `/${restApiEcm}/remove`;
        break;
      case 'alterarDescricao':
        url = `/${restApiEcm}/updateDescription`;
        break;
      case 'alterar':
        url = `/${restApiEcm}/updateDocumentFolder`;
        break;
      default:
        Util.exibirToast('Erro!', 'Função não encontrada.', 'danger', 4000);
        console.log('Função ajax não encontrada.');
        return null;
    }
    if (funcao == 'upload') {
      $.ajax({
        async: assincrono,
        url: top.WCMAPI.getServerURL() + url,
        crossDomain: true,
        type: metodo,
        data: dadosJson,
        cache: false,
        processData: false,
        contentType: false,
        headers: oauth.toHeader(oauth.authorize({ url: top.WCMAPI.getServerURL() + url, method: metodo }, token)),
        success: (dados) => {
          resultado = dados;
        },
        error: (objErro, status, msg) => {
          console.log(`Erro: ${status} - ${msg}`);
          resultado = objErro;
        }
      });

    } else {

      $.ajax({
        async: assincrono,
        url: top.WCMAPI.getServerURL() + url,
        type: metodo,
        headers: oauth.toHeader(oauth.authorize({ url: top.WCMAPI.getServerURL() + url, method: metodo }, token)),
        data: typeof dadosJson == 'string' ? dadosJson : JSON.stringify(dadosJson),
        contentType: 'application/json',
        success: (dados) => {
          resultado = dados;
        },
        error: (objErro, status, msg) => {
          console.log(`Erro: ${status} - ${msg}`);
          resultado = objErro;
        }
      });
    }

    return resultado;
  }

  // static anexarArquivo(elementoAnexoDOM, categoria, callback) {
  //   $(() => {
  //     $(elementoAnexoDOM).fileupload({
  //       dataType: 'json',
  //       done: (e, data) => {
  //         let nomeArquivo = 'arquivo';
  //         Util.carregamento(() => {
  //           let jsonPastas = FluigFile.verificarCriarEstrutura(categoria);
  //           $.each(data.result.files, (index, file) => {
  //             let nomeArquivo = FluigFile.formatarNomeArquivo(file.name, categoria, jsonPastas);
  //             const arquivo = FluigFile.gravarArquivo(jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].id, nomeArquivo, file.name);
  //             if (arquivo.hasOwnProperty('content')) {
  //               jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].arquivos.push({
  //                 id: arquivo.content.id,
  //                 index: jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].arquivos.length + 1,
  //                 nome: nomeArquivo,
  //                 ativo: 0
  //               });
  //               $('#jsonPastas').val(JSON.stringify(jsonPastas));
  //               Util.exibirToast('OK!', 'Arquivo salvo com sucesso no ECM do fluig.', 'success');
  //               callback(elementoAnexoDOM);
  //             } else {
  //               Util.exibirToast('Atenção!', 'Erro ao salvar arquivo no ECM do fluig.', 'danger');
  //             }
  //           });
  //         }, `Salvando ${nomeArquivo} no fluig, por favor aguarde...`);
  //       }
  //     });
  //   });
  // }
  static anexarArquivo(arquivos, categoria) {
    // Util.carregamento(() => {
    this.ajaxApi("upload", arquivos.filecontent)

    let jsonPastas = FluigFile.verificarCriarEstrutura(categoria);
    for (let i = 0; i < arquivos.length; i++) {
      let nomeArquivo = FluigFile.formatarNomeArquivo(arquivos[i].description, categoria, jsonPastas);
      const arquivo = FluigFile.gravarArquivo(jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].id, nomeArquivo, arquivos[i].description);
      if (arquivo.hasOwnProperty('content')) {
        jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].arquivos.push({
          id: arquivo.content.id,
          index: jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].arquivos.length + 1,
          nome: nomeArquivo,
          ativo: 0
        });
        $('#jsonPastas').val(JSON.stringify(jsonPastas));
        Util.exibirToast('OK!', 'Arquivo salvo com sucesso no ECM do fluig.', 'success');
      } else {
        Util.exibirToast('Atenção!', 'Erro ao salvar arquivo no ECM do fluig.', 'danger');
      }
    }
    // }, `Salvando ${nomeArquivo} no fluig, por favor aguarde...`);
  }

  static formatarNomeCategoria(categoria) {
    const nomeCategoria = {
      'anexoCadastroCliente': 'Arquivos Cadastro Cliente - Anexos',
      'default': categoria
    }
    return nomeCategoria[categoria] || nomeCategoria['default'];
  }

  static getOpcaoVersionamentoCategoria(categoria) {
    const versionOptions = {
      'default': VersionOptions.MANTER_VERSAO
    }
    return versionOptions[categoria] || versionOptions['default'];
  }

  static obterUrlArquivo(idArquivo) {
    return `${top.WCMAPI.serverURL}/portal/p/CAPUL/ecmnavigation?app_ecm_navigation_doc=${idArquivo}`;
  }

  /**
 * Função que busca uma pasta específica através da descrição à partir de uma pasta pai.
 *
 * @param {string} codigoPastaPai Código da pasta pai no fluig.
 * @param {string} descricaoPasta descrição (nome) da pasta.
 *
 * @returns {string} Retorna o código da pasta encontrada ou null caso não exista.
 */
  static buscarPasta(codigoPastaPai, descricaoPasta) {
    const listaDePastasFilhas = FluigFile.ajaxApi('listarDocumentos', codigoPastaPai);
    let idPasta = null;
    listaDePastasFilhas.content.forEach(pasta => {
      if (pasta.description == descricaoPasta) {
        idPasta = pasta.id;
      }
    });
    return idPasta;
  }

  static getDocumentosPasta(codigoPastaPai) {
    return FluigFile.ajaxApi('listarDocumentos', codigoPastaPai);
  }

  static criarPasta(codigoPastaPai, descricaoPasta, tipoVersionamento) {
    const dados = FluigFile.montarDadosPasta(codigoPastaPai, descricaoPasta, tipoVersionamento);
    const codigoPastaCriada = FluigFile.ajaxApi('criarPasta', JSON.stringify(dados));
    if (tipoVersionamento != VersionOptions.MANTER_VERSAO) {
      FluigFile.ajaxApi('alterar', JSON.stringify(FluigFile.montarDadosAlterarVersionamento(codigoPastaCriada, descricaoPasta, tipoVersionamento)));
    }
    return codigoPastaCriada;
  }

  static excluirArquivoPasta(id) {
    const dados = JSON.stringify({
      id
    });
    const arquivoFoiExcluido = FluigFile.ajaxApi('remover', dados);
    if (arquivoFoiExcluido.hasOwnProperty('content')) {
      Util.exibirToast('OK!', 'Arquivo excluído com sucesso.', 'success');
      return true;
    } else {
      Util.exibirToast('Atenção!', 'Erro ao excluir arquivo.', 'danger');
      return false;
    }
  }

  static deletarArquivoPasta(id) {
    const dados = JSON.stringify({
      id
    });
    const arquivoFoiExcluido = FluigFile.ajaxApi('remover', dados);
    if (arquivoFoiExcluido.hasOwnProperty('content')) {
      // Util.exibirToast('OK!', 'Arquivo excluído com sucesso.', 'success');
      return true;
    } else {
      //Util.exibirToast('Atenção!', 'Erro ao excluir arquivo.', 'danger');
      return false;
    }
  }

  /**
   * Função que monta os dados para criação de uma pasta em um JSON.
   *
   * @param {String} codigoPastaPai Código da pasta pai no fluig.
   * @param {String} descricaoPasta descrição (nome) da pasta.
   *
   * @return {Object} Retorna JSON com os dados que serão enviados na requisição.
   */
  static montarDadosPasta(codigoPastaPai, descricaoPasta) {
    return {
      'publisherId': 'admin',
      'documentDescription': descricaoPasta,
      'parentFolderId': codigoPastaPai,
      'publisherId': 'admin',
      'additionalComments': 'Pasta criada automaticamente pelo fluig.',
      'inheritSecurity': true,
      'permissionType': 12345,
      'restrictionType': 12345
    };
  }

  static montarDadosAlterarVersionamento(codigoDocumento, descricao, tipoVersionamento) {
    return {
      'documentId': codigoDocumento,
      'version': 1000,
      'documentDescription': descricao,
      'versionAction': '',
      'versionOption': tipoVersionamento,
      'additionalComments': 'Tipo de versionamento: revisão',
      'inheritSecurity': true,
      'downloadEnable': true
    }
  }

  static getJsonPastas() {
    const jsonAtual = $('#jsonPastas').val();
    if (Util.estaVazio(jsonAtual)) {
      return FluigFile.getJsonEstruturaInicial();
    } else {
      return JSON.parse(jsonAtual);
    }
  }

  static getJsonPadraoCategoria(categoria) {
    return {
      [categoria]: {
        id: '',
        desc: this.formatarNomeCategoria(categoria),
        arquivos: []
      }
    }
  }

  static getJsonPadrao(idPastaSolicitacoes) {
    return {
      pastaRaiz: {
        id: idPastaSolicitacoes,
        desc: '',
        filhos: {
          pastaSolicitacao: {
            id: '',
            desc: '',
            filhos: {
              /** Categorias */
            }
          }
        }
      }
    }
  }

  /**
* Função à ser executada antes de salvar arquivos.
* Busca e cria pastas no ECM de acordo com o número da solicitação e o nome do solicitante, sendo que cada despesa também possui sua pasta.
*
* @param {String} categoria Categoria do anexo. São aceitos:
* 	- 'notaTecnica'
*  - 'cestaCotacoes'
* 	- 'rps'
* 	- 'docForn'
*
* @returns {String} Código da pasta existente ou já criada para os comprovantes da solicitação.
*/
  static verificarCriarEstrutura(categoriaAnexo) {
    const jsonPastas = FluigFile.getJsonPastas();
    if (jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoriaAnexo] == undefined) {
      let jsonCategoria = FluigFile.getJsonPadraoCategoria(categoriaAnexo);
      jsonCategoria[categoriaAnexo].id = FluigFile.verificarCriarPasta(
        jsonPastas.pastaRaiz.filhos.pastaSolicitacao.id,
        this.formatarNomeCategoria(categoriaAnexo),
        this.getOpcaoVersionamentoCategoria(categoriaAnexo)
      );
      jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoriaAnexo] = jsonCategoria[categoriaAnexo];
      $('#jsonPastas').val(JSON.stringify(jsonPastas));
      return jsonPastas;
    } else {
      return jsonPastas;
    }
  }

  /**
 * Função genérica para verificar se uma pasta existe no Fluig e, caso não, criar.
 * @param {Integer} idPastaPai Código da pasta pai a ser buscada / criada.
 * @param {String} descricaoPastaFilha Descrição da pasta a ser buscada / criada.
 * @return {Null / Intger} Código da pasta criada.
 */
  static verificarCriarPasta(idPastaPai, descricaoPastaFilha, tipoVersionamento) {
    let codigoPastaEncontrada = FluigFile.buscarPasta(idPastaPai, descricaoPastaFilha);
    let codigoPastaCriada;
    if (Util.estaVazio(codigoPastaEncontrada)) {
      codigoPastaCriada = (FluigFile.criarPasta(idPastaPai, descricaoPastaFilha, tipoVersionamento)).content.documentId;
      if (Util.estaVazio(codigoPastaCriada)) {
        Util.exibirToast('Atenção!', `Erro ao criar pasta de descrição: ${descricaoPastaFilha}.`, 'danger');
        return null;
      }
      return codigoPastaCriada;
    } else {
      return codigoPastaEncontrada;
    }
  }

  static getJsonEstruturaInicial() {
    const CODIGO_PASTA_RAIZ_CADASTRO_CLIENTE = "3213";
    let jsonInicial = FluigFile.getJsonPadrao(CODIGO_PASTA_RAIZ_CADASTRO_CLIENTE);
    const numeroSolicitacao = "";
    const nomeSolicitante = $('#nomeSolicitante').val();
    let descricaoPastaSolicitacao = Util.estaVazio(numeroSolicitacao) ? 'Solicitação em fase de inicialização' : `${numeroSolicitacao}`;
    descricaoPastaSolicitacao += ` - ${nomeSolicitante}`;
    let codigoPastaCriada = (FluigFile.criarPasta(CODIGO_PASTA_RAIZ_CADASTRO_CLIENTE, descricaoPastaSolicitacao)).content.documentId;
    if (Util.estaVazio(codigoPastaCriada)) {
      Util.exibirToast('Atenção!', `Erro ao criar pasta de descrição: ${descricaoPastaFilha}.`, 'danger');
      return null;
    }

    jsonInicial.pastaRaiz.id = CODIGO_PASTA_RAIZ_CADASTRO_CLIENTE;
    jsonInicial.pastaRaiz.filhos.pastaSolicitacao.id = codigoPastaCriada;
    jsonInicial.pastaRaiz.filhos.pastaSolicitacao.desc = descricaoPastaSolicitacao;
    return jsonInicial;
  }


  /**
 * Função usada para gravar um arquivo no ECM.
 *
 * @param {string} codigoPasta Id da pasta onde o arquivo deve ser gravado.
 * @param {string} nomeArquivoTratado Descrição do arquivo no ECM.
 * @param {string} nomeArquivoOriginal Descrição original do arquivo.
 *
 * @returns {Object} O resultado da requisição ajax.
 */
  static gravarArquivo(codigoPasta, nomeArquivoTratado, nomeArquivoOriginal) {
    const dados = JSON.stringify({
      'description': nomeArquivoTratado,
      'parentId': codigoPasta,
      'activeVersion': true,
      'inheritSecurity': true,
      'attachments': [{
        'fileName': nomeArquivoOriginal,
        'principal': true
      }],
      'downloadEnabled': true,
    });

    return FluigFile.ajaxApi('criarArquivo', dados);
  }

  static formatarNomeArquivo(nomeArquivo, categoria, jsonPastas) {
    let posicaoFormatoArquivo = nomeArquivo.lastIndexOf('.');
    nomeArquivo = nomeArquivo.substring(0, posicaoFormatoArquivo) + ' - ';
    if (jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].hasOwnProperty('id')) {
      let qtdArquivos = jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria].arquivos.length + 1; //tipos[tipo].categorias[categoria].arquivos.length + 1;
      nomeArquivo += (qtdArquivos > 9 ? qtdArquivos : '0' + qtdArquivos);
    } else {
      nomeArquivo += '01';
    }
    return nomeArquivo;
  }


  controlarBotoesAnexo(elementoDOM, acao, categoria) {
    if (acao == AcaoAnexo.ANEXAR) {
      this.anexarArquivo(elementoDOM, categoria);
    }
    if (acao == AcaoAnexo.VISUALIZAR) {
      if (categoria == 'solicitacao') {
        this.visualizarPastaSolicitacao();
      } else {
        this.visualizarArquivoCategoria(elementoDOM, categoria);
      }
    }
    if (acao == AcaoAnexo.EXCLUIR) {
      this.excluirArquivo(elementoDOM, categoria);
    }
  }

  static verificarExclusaoPastasEmCadeia(jsonPastas, categoria) {
    const quantidadeArquivosCategoria = jsonPastas.pastaRaiz.filhos.
      pastaSolicitacao.filhos[categoria].arquivos.length;
    if (quantidadeArquivosCategoria < 1) {
      FluigFile.deletarCategoria(jsonPastas, categoria, jsonPastas.pastaRaiz.filhos.
        pastaSolicitacao.filhos[categoria].id);
    }
  }

  static deletarCategoria(jsonPastas, categoria, idCategoria) {
    if (Object.keys(jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos).length < 2) {
      const idPastaSolicitacao = jsonPastas.pastaRaiz.filhos.pastaSolicitacao.id;
      FluigFile.deletarSolicitacao(jsonPastas, idPastaSolicitacao);
    } else {
      FluigFile.deletarArquivoPasta(idCategoria);
      delete jsonPastas.pastaRaiz.filhos.pastaSolicitacao.filhos[categoria];
      $('#jsonPastas').val(JSON.stringify(jsonPastas));
    }
  }

  static deletarSolicitacao(jsonPastas, idSolicitacao) {
    FluigFile.deletarArquivoPasta(idSolicitacao);
    delete jsonPastas.pastaRaiz.filhos.pastaSolicitacao;
    $('#jsonPastas').val('{}');
  }

  static deletarRaiz(jsonPastas, idPastaRaiz) {
    FluigFile.excluirArquivoPasta(idPastaRaiz);
    delete jsonPastas.pastaRaiz;
    $('#jsonPastas').val('{}');
  }

}

class AcaoAnexo {
  static get ANEXAR() {
    return 0;
  }
  static get ANEXADO() {
    return 1;
  }
  static get EXCLUIR() {
    return 2;
  }
  static get VISUALIZAR() {
    return 3;
  }
}

class VersionOptions {
  static get MANTER_VERSAO() {
    return '0';
  }
  static get CRIAR_NOVA_REVISAO() {
    return '1';
  }
  static get CRIAR_NOVA_VERSAO() {
    return '2';
  }
}