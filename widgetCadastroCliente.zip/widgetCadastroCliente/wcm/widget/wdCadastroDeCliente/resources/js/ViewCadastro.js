class ViewCadastro{
       
    avisoCadastro(){
        let select = $("#tipoCadastro").val();
        //document.getElementById('radio-1c').checked == false) && (document.getElementById('radio-2c').checked == false

        if (document.getElementById('radio-1c').checked) {
           let stg = ViewCadastro
        .optionFisica(select);
           $("#divAlert").html(stg);
        }

        if(document.getElementById('radio-2c').checked){
            let stg = ViewCadastro
        .optionjuridica(select);
            $("#divAlert").html(stg);
        }
    }

    static optionFisica(text){
        let mensagem = "";
        switch(text){
            case "Cadastro Simples":
            mensagem = `
            <p>Anexos Obrigatórios</p><br>
            <p>Cópia dos documentos pessoais (RG E CPF)</p><br>
            <p>Cópia do comprovante de Inscrição Estadual de Produtor Rural (caso tenha)</p>`;
            break;

            case "Cadastro Cliente":
                mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF)</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do cônjuge</p><br>
                <p>Comprovante de renda atualizado</p><br>
                <p>Cópia do comprovante de endereço para correspondência atualizado</p><br>`;
            break;
            case "Cadastro Cooperado":
                mensagem= `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do pretendente</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do cônjuge</p><br>
                <p>Cópia da certidão de casamento</p><br>
                <p>Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal,
                    inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas
                    onde tenha residido nos últimos 05 (cinco) anos;
                </p><br>
                <p>Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta)
                    dias.</p><br>
                <p>Cópia do comprovante de Inscrição Estadual de Produtor Rural</p><br>
                <p>Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de
                    arrendamento rural devidamente registrado</p><br>
                <p>Cópia da declaração do ITR do exercício atual</p><br>
                <p>Cópia da ficha sanitária do rebanho atualizada</p><br>
                <p>Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias</p><br>
                <p>Comprovante de renda</p><br>`;
            break;
            default:
                mensagem = "Preencha o tipo de cadastro";
        }

        return mensagem;
    }

   static optionjuridica(text){
        let mensagem = "";
        switch(text){
            case "Cadastro Simples":
                mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>`;
            break;

            case "Cadastro Cliente":
                mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges</p><br>
                <p>Cópia do comprovante de endereço para correspondência atualizado</p><br>
                <p>Cópia comprovante de renda atualizado</p><br>`;
            break;

            case "Cadastro Cooperado":
                mensagem= `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges</p><br>
                <p>Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal,
                    inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas
                    onde tenha se estabelecido nos últimos 05 (cinco) anos
                </p><br>
                <p>Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta)
                    dias</p><br>
                <p>Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de
                    arrendamento rural devidamente registrado</p><br>
                <p>Cópia da declaração do ITR do exercício atual</p><br>
                <p>Cópia da ficha sanitária do rebanho atualizada</p><br>
                <p>Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias</p><br>
                <p>Comprovante de renda</p><br>`;
            break;
            default:
                mensagem = "Preencha o tipo de cadastro";
        }

        return mensagem;
    }
    
}


        /* 
                    switch(select){
                case "Cadastro Simples":
                        fisic
                        
                            Anexos Obrigatórios


                            Cópia dos documentos pessoais (RG E CPF)


                            Cópia do comprovante de Inscrição Estadual de Produtor Rural (caso tenha)

                        jud
                        Cópia CNPJ e Inscrição Estadual
                        
                break;

                case "Cadastro Cliente":
                    fisic
                        Cópia dos documentos pessoais (RG E CPF)

                        Cópia dos documentos pessoais (RG E CPF) do cônjuge


                        Comprovante de renda atualizado


                        Cópia do comprovante de endereço para correspondência atualizado

                    jud
                        Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)

                        Cópia CNPJ e Inscrição Estadual


                        Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges


                        Cópia do comprovante de endereço para correspondência atualizado


                        Cópia comprovante de renda atualizado

                break;
                case "Cadastro Cooperado":
                    fisic
                        Cópia dos documentos pessoais (RG E CPF) do pretendente

                        Cópia dos documentos pessoais (RG E CPF) do cônjuge


                        Cópia da certidão de casamento


                        Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal, inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas onde tenha residido nos últimos 05 (cinco) anos;


                        Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta) dias.


                        Cópia do comprovante de Inscrição Estadual de Produtor Rural


                        Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de arrendamento rural devidamente registrado


                        Cópia da declaração do ITR do exercício atual


                        Cópia da ficha sanitária do rebanho atualizada


                        Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias


                        Comprovante de renda

                    jud
                        Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)

                        Cópia CNPJ e Inscrição Estadual


                        Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges


                        Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal, inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas onde tenha se estabelecido nos últimos 05 (cinco) anos


                        Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta) dias


                        Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de arrendamento rural devidamente registrado


                        Cópia da declaração do ITR do exercício atual


                        Cópia da ficha sanitária do rebanho atualizada


                        Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias


                        Comprovante de renda
                break;

                default:
                    return "";
            }



        */
