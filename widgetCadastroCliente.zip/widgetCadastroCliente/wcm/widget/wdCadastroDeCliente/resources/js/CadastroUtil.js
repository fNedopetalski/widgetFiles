class CadastroUtil {
  constructor() { }

  /**
   * Mascara do campo - CPF/CNPJ, altera dinamicamente
   * @param campo     - Campos do FormulÃ¡rio
   * @param teclapres - Tecla pressionada
   * @returns {Boolean}
   */
  static mascaraCnpj(campo, teclapres) {
    let tecla = teclapres.keyCode;
    if ((tecla < 48 || tecla > 57) && (tecla < 96 || tecla > 105) && tecla != 46 && tecla != 8 && tecla != 9) {
      return false;
    }
    let vr = campo.value;
    vr = vr.replace(/\//g, "");
    vr = vr.replace(/-/g, "");
    vr = vr.replace(/\./g, "");
    let tam = vr.length;
    if (tam <= 2) {
      campo.value = vr;
    }
    if ((tam > 2) && (tam <= 5)) {
      campo.value = vr.substr(0, tam - 2) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam >= 6) && (tam <= 8)) {
      campo.value = vr.substr(0, tam - 5) + '.' + vr.substr(tam - 5, 3) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam >= 9) && (tam <= 11)) {
      campo.value = vr.substr(0, tam - 8) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam == 12)) {
      campo.value = vr.substr(tam - 12, 3) + '.' + vr.substr(tam - 9, 3) + '/' + vr.substr(tam - 6, 4) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam > 12) && (tam <= 14)) {
      campo.value = vr.substr(0, tam - 12) + '.' + vr.substr(tam - 12, 3) + '.' + vr.substr(tam - 9, 3) + '/' + vr.substr(tam - 6, 4) + '-' + vr.substr(tam - 2, tam);
    }
    if (tam > 13) {
      if (tecla != 8) {
        return false
      }
    }
  }

  static loading(fn, msg = 'Por favor, aguarde...') {
		let loading = FLUIGC.loading(window, {
			textMessage: msg
		});
		loading.show();
		setTimeout(function () {
			fn();
			loading.hide();
		}, 300);
	}

  static mascaraCpf(campo, teclapres) {
    let tecla = teclapres.keyCode;
    if ((tecla < 48 || tecla > 57) && (tecla < 96 || tecla > 105) && tecla != 46 && tecla != 8 && tecla != 9) {
      return false;
    }
    let vr = campo.value;
    vr = vr.replace(/-/g, "");
    vr = vr.replace(/\./g, "");
    let tam = vr.length;
    if (tam <= 2) {
      campo.value = vr;
    }
    if ((tam > 2) && (tam <= 5)) {
      campo.value = vr.substr(0, tam - 2) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam >= 6) && (tam <= 8)) {
      campo.value = vr.substr(0, tam - 5) + '.' + vr.substr(tam - 5, 3) + '-' + vr.substr(tam - 2, tam);
    }
    if ((tam >= 9) && (tam <= 11)) {
      campo.value = vr.substr(0, tam - 8) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) + '-' + vr.substr(tam - 2, tam);
    }
    if (tam > 10) {
      if (tecla != 8) {
        return false
      }
    }
  }

  static mascaraTelefone(campo, teclapres) {
    let tecla = teclapres.keyCode;
    if ((tecla < 48 || tecla > 57) && (tecla < 96 || tecla > 105) && tecla != 46 && tecla != 8 && tecla != 9) {
      return false;
    }
    let vr = campo.value;
    vr = vr.replace(/\(/g, "");
    vr = vr.replace(/-/g, "");
    vr = vr.replace(/\)/g, "");
    vr = vr.replace(/\s/g, "");
    let tam = vr.length;
    if (tam <= 2) {
      campo.value = vr;
    }
    if ((tam > 2) && (tam <= 4)) {
      campo.value = vr.substr(0,0) + '(' + vr.substr(0,2)+")" + vr.substr(2,tam);
    }
    if ((tam >= 5) && (tam <= 7)) {
      campo.value = vr.substr(0,0) + '(' + vr.substr(0,2)+") " + vr.substr(2,tam);
    }
    if ((tam >= 8) && (tam <= 10)) {
      campo.value = vr.substr(0,0) + '(' + vr.substr(0,2)+") " + vr.substr(2,4) + '-' + vr.substr(6,tam);
    }
    if (tam == 11) {
      campo.value = vr.substr(0,0) + '(' + vr.substr(0,2)+") " + vr.substr(2,5) + '-' + vr.substr(7,tam);
    }
    if (tam > 10) {
      if (tecla != 8) {
        return false
      }
    }
  }


}