var table = new Object();
class CadastroController {
  constructor() {
    this._CadastroView = new CadastroView();
    this._CadastroValidate = new CadastroValidate();
    // this._CadastroUtil = new CadastroUtil();

    this._hideBar();
    this._createListeners();
    this._getDate();
    this._getNome();
    this._checkFilial();
    this.initTableAnex();
    this._createInputsMask();

    this._idFluig = window.location.href.split('?')

    if (this._idFluig[1] != '' && this._idFluig[1]) {
      this._CadastroView.carregarDadosCorrigir(CadastroModel.buscarDadosForm(this._idFluig[1]))
    }
  }

  static deleteFile(el) {
    el.closest('tr').remove();
  }

  _createListeners() {
    $("#btnEnviaSolicitacaoCadastro").on("click", event => {
      event.preventDefault();
      this._CadastroValidate.validateInput();
      this._inicializarSolicitacao();
    })

    $(".exit").on("click", event => {
      if (confirm("Você tem certeza que deseja descartar essa solicitação?")) {
        window.location.assign(`/portal/CAPUL/portal_representantes/home`);
      }
    })

    $("#btnIncludeAnex").on("click", event => {
      this.addAnex();
    });

    $('#tipoCadastro').on("change", event => {
      this._CadastroView.avisoCadastro();
    });
    $('input[name="radio-types"]').on("change", event => {
      this._CadastroView.avisoCadastro();
    });

  }

  _createInputsMask() {
    $("#valor_credito").maskMoney({ prefix: 'R$ ', allowNegative: true, thousands: '.', decimal: ',', affixesStay: false });
  }

  _checkFilial() {
    var filial = JSON.parse(sessionStorage.dados_pessoais);
    if (filial[1].FILIAL === "sim") {
      $("#area").val(filial[1].NOMEFILIAL);
    } else {
      $("#area").val("REPRESENTANTE");
    }
  }

  _inicializarSolicitacao() {
    CadastroUtil.loading(() => {
      if (this._CadastroValidate.allCorrect() != false) {

        let files = new Array();
        $.makeArray($("#tableAnexo").find("input")).forEach(el => {
          files.push(
            {
              filename: $(el).attr(`nameFile`),
              filecontent: $(el).attr(`base64`)
            }
          )
        });

        let anexos = new Array();
        for (let i = 0; i < files.length; i++) {
          anexos.push(
            {
              filename: files[i].filename,
              filecontent: files[i].filecontent,
              description: files[i].filename
            }
          )
        }

        if (anexos.length > 0) {
          for (let i = 0; i < anexos.length; i++) {
            FluigFile.anexarArquivo(anexos[i], "anexoCadastroCliente", () => { });
          }
        }

        if ($("#tipoCadastro").val() == "1") {
          var fields = ["processo_de_cadastro_cliente_IGNE", "9", '', "Solicitação aberta pelo Portal De Representantes", "admin", "true", "false", "1", JSON.stringify({ anexos })];
        } else {
          var fields = ["processo_de_cadastro_cliente_IGNE", "1", '', "Solicitação aberta pelo Portal De Representantes", "admin", "true", "false", "1", JSON.stringify({ anexos })];
        }
        var constraints = new Array();
        var session = JSON.parse(sessionStorage.dados_pessoais);
        var codigoUser = session[1].CODIGOUSER;

        constraints.push(
          DatasetFactory.createConstraint("nome_completo", $("#nome_completo").val(), $("#nome_completo").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("valor_credito", $("#valor_credito").val(), $("#valor_credito").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("inscricao_estadual", $("#inscricao_estadual").val(), $("#inscricao_estadual").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("codigoUser", codigoUser, codigoUser, ConstraintType.MUST),
          DatasetFactory.createConstraint("escCNPJ", $("#escCNPJ").val(), $("#escCNPJ").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("escCPF", $("#escCPF").val(), $("#escCPF").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("email", $("#email").val(), $("#email").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("telefone", $("#telefone").val(), $("#telefone").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("observacoes", $("#observacoes").val(), $("#observacoes").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("radio_cadastro", $("input[id^='radio-']:checked").val(), $("input[id^='radio-']:checked").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("fisicoJuridico", $("input[id^='radio-']:checked").val(), $("input[id^='radio-']:checked").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("tipo_cadastro", $("#tipoCadastro").val(), $("#tipoCadastro").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("dataSolicitacao", $("#dataSolicitacao").val(), $("#dataSolicitacao").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("nomeSolicitante", $("#nomeSolicitante").val(), $("#nomeSolicitante").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("areaSolicitante", $("#area").val(), $("#area").val(), ConstraintType.MUST),
          DatasetFactory.createConstraint("jsonPastas", JSON.stringify({}), JSON.stringify({}), ConstraintType.MUST),
        );

        var retornoDadosDataset = "";

        if (this._idFluig[1] != '' && this._idFluig[1]) {
          constraints.push(DatasetFactory.createConstraint("codFluig", this._idFluig[1], this._idFluig[1], ConstraintType.MUST))
          var fieldsSaveAndSend = [this._idFluig[1], "15", '', "Solicitação retornada pelo Portal de Representantes", "admin", "true", "false", "1", "0"];
          retornoDadosDataset = DatasetService.getDataset("dsSaveAndSendTask", fieldsSaveAndSend, constraints, null);
        } else {
          retornoDadosDataset = DatasetService.getDataset("dsStartProcessWorkflowService", fields, constraints, null);
        }
        if (retornoDadosDataset == '' || retornoDadosDataset == null || retornoDadosDataset == undefined) {
          FLUIGC.toast({
            title: 'Falha!',
            message: 'Não foi possivel iniciar a solicitação',
            type: 'warning',
          })
        }
        if (retornoDadosDataset.values[0].msgRetorno == '') {
          FLUIGC.toast({
            title: 'Falha!',
            message: 'Não foi possivel iniciar a solicitação',
            type: 'warning',
          })
        } else {
          var iProcess = retornoDadosDataset.values[0].msgRetorno;
          $('#iProcess').val(iProcess);
        }
        setTimeout(() => {
          window.location.assign(`/portal/CAPUL/portal_representantes/home`);
        }, 2000);
        FLUIGC.toast({
          title: 'Sucesso!',
          message: `Solicitação ${$("#iProcess").val()} enviada com sucesso`,
          type: 'success'
        })
      } else {
        return;
      }
    });

  }

  _getNome() {
    var nome = JSON.parse(sessionStorage.dados_pessoais);
    $('#nomeSolicitante').val(nome[1].NOME);
  }

  _getDate() {
    var date = new Date();
    var ano = date.getFullYear();
    var mes = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1);
    var dia = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var hora = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var minutos = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var segundos = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

    var dataCompleta = `${dia}/${mes}/${ano} ${hora}:${minutos}:${segundos}`;

    $('#dataSolicitacao').val(dataCompleta);
  }

  _hideBar() {
    $('#liquidHeader_295008').parent().remove();
  }

  initTableAnex() {

    table["tableAnex"] = FLUIGC.datatable('#tableAnexo', {
      dataRequest: [],
      renderContent: ['button', 'remove'],
      header: [
        { 'title': 'Arquivo' },
        { 'title': '#' }
      ], search: {
        enabled: false
      }
    }, function (err, data) {
    });
  }

  addAnex() {
    table.tableAnex.addRow(0, {
      'button': `<input type="file" onchange="CadastroController.preparaArquivo(this)"></button>`,
      'remove': `<button type="button" class="btn btn-danger" onclick="CadastroController.deleteFile(this)"><i class="fluigicon fluigicon-remove-circle icon-sm"></i></button>`
    });
  }

  static async preparaArquivo(element) {
    const toBase64 = file => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
    })

    for (let i = 0; i < element.files.length; i++) {
      let base64 = await toBase64(element.files[i]);
      base64 = base64.split("base64,")

      let input = $(element);

      $(element).attr(`base64`, base64[1]);
      var filename = input[0].files[i].name;
      $(element).attr(`nameFile`, filename);
    }
  }

}