class CadastroView {

  avisoCadastro() {
    let select = $("#tipoCadastro").val();
    $("#divCredito").hide();

    if (document.getElementById('radio-1c').checked) {
      $("#divcpf").show();
      $("#divcnpj").hide();
      if (select != null) {
        $("#divAlert").show();
        let stg = CadastroView.optionFisica(select);
        $("#divAlert").html(stg);
      }
    }

    if (document.getElementById('radio-2c').checked) {
      $("#divcpf").hide();
      $("#divcnpj").show();
      if (select != null) {
        $("#divAlert").show();
        let stg = CadastroView.optionjuridica(select);
        $("#divAlert").html(stg);
      }
    }
  }

  carregarDadosCorrigir(lista) {
    CadastroUtil.loading(() => {

      const c1 = DatasetFactory.createConstraint("idForm", lista[1], lista[1], ConstraintType.MUST)
      const c2 = DatasetFactory.createConstraint("datasetName", "dsFormCadastroClienteIgne", "dsFormCadastroClienteIgne", ConstraintType.MUST)
      const c3 = DatasetFactory.createConstraint("dataTable", "tableHistoricoXX", "tableHistoricoXX", ConstraintType.MUST)
      const dsResult = DatasetService.getDataset("dsSearchTableForm", null, [c1, c2, c3], null);

      if (dsResult != undefined) {
        dsResult.values.sort((a, b) => {
          if (a["wdk_sequence_id"] < b["wdk_sequence_id"]) {
            return -1
          } else {
            return true
          }
        });
        this.exibirPaineisHistorico(dsResult.values)
      }

      lista[0].map(a => {
        $('#dataSolicitacao').val(a.dataSolicitacao)
        $('#nomeSolicitante').val(a.nomeSolicitante)
        $('#areaSolicitante').val(a.areaSolicitante)
        $('#tipoCadastro').val(a.tipo_cadastro)
        $('#valor_credito').val(a.valor_credito)
        $('#nome_completo').val(a.nome_completo)
        $('#escCPF').val(a.escCPF)
        $('#escCNPJ').val(a.escCNPJ)
        $('#inscricao_estadual').val(a.inscricao_estadual)
        $('#email').val(a.email)
        $('#telefone').val(a.telefone)
        $('#observacoes').val(a.observacoes)

        this.montaTableAnexos(a.codFluig)

        if (a["radio_cadastro"] == "juridico") {
          $("#divcpf").hide();
          $("#divcnpj").show();
          $("#radio-2c").prop("checked", true)
        } else {
          $("#divcpf").show();
          $("#divcnpj").hide();
          $("#radio-1c").prop("checked", true)
        }
        if (a["tipo_cadastro"] == "2") {
          $("#divCredito").show();
        }
      })

    });
  }


  exibirPaineisHistorico(dsResult) {

    for (let i = dsResult.length - 1; i >= 0; i--) {

      var indexHistorico = dsResult[i].indiceHistorico;

      /** INSERE PAINEL DE HISTÓRICO LOGO APÓS O PAINEL ORIGINAL DE SOLICITAÃO Ç*/
      $(`<div class="panel panel-primary" id="idPainelHistorico___${indexHistorico}">` + dsResult[i].painelHistorico1 +
        dsResult[i].painelHistorico2 + dsResult[i].painelHistorico3 + dsResult[i].painelHistorico4 + "</div>")
        .insertAfter("#painelSolicitante")

      var valuesInputs = JSON.parse(dsResult[i].valuesCamposHistorico)

      /** ATUALIZA O VALOR DO HREF DOS COLLAPSES PARA QUE NÃO HAJA CONFLITO COM O PAINEL ORIGINAL */
      let hrefCollpase = $(`#idPainelHistorico___${indexHistorico}`).find("[href^='#collapse']").attr("href")
      $(`#idPainelHistorico___${indexHistorico}`).find("[href^='#collapse']").attr("href", "#" + (indexHistorico) + "_" + (hrefCollpase.split("#")[1]))

      $.makeArray($(`#idPainelHistorico___${indexHistorico}`).find("[href^='#collapse']")).forEach(fieldset => {
        let hrefFieldset = $(fieldset).attr("href");
        $(fieldset).attr("href", "#" + (indexHistorico) + "_" + (hrefFieldset.split("#")[1]))
      })

      /** ATUALIZA HEADER DO PAINEL HISTÓRICO, ADICIONANDO O INDICE, NOME DO SOLICITANTE E A DATA  */
      $(`#idPainelHistorico___${indexHistorico}`).find(`[href^='#${indexHistorico}_collapse']`).find("b")
        .before(`<b>${indexHistorico}. </b>`)
        .after(`<span>  |  ${dsResult[i].nomeSolicitanteHistorico} ${dsResult[i].dataHistorico}</span>`)

      /** REMOVE BOTÕES DE ANEXAR E DE EXCLUIR ANEXO */
      $(`#idPainelHistorico___${indexHistorico}`).find(".btn-danger").remove()
      $(`#idPainelHistorico___${indexHistorico}`).find(".file-input-wrapper").parent().remove()
      $(`#idPainelHistorico___${indexHistorico}`).find(`#${indexHistorico}_botaoAdicionarItem`).remove()
      $(`#idPainelHistorico___${indexHistorico}`).find(`.fluigicon-trash`).remove()

      /** CONTRAI COLLAPSE  */
      $(`#idPainelHistorico___${indexHistorico}`).find(".in").removeClass("in")

      /** PERCORRE O PAINEL DE HISTÓRICO PARA ENCONTRAR TODOS OS RADIOS E DESMARCALOS */
      $.makeArray($(`#idPainelHistorico___${indexHistorico}`).find("[id]")).forEach(el => {
        if ($(el).attr("type") == "radio") {
          $(el).prop("checked", false);
        }
      })

      /** PERCORRE O PAINEL DE HISTÓRICO PARA ENCONTRAR TODOS OS ELEMENTOS QUE TENHAM ID */
      $.makeArray($(`#idPainelHistorico___${indexHistorico}`).find("[id]")).forEach(el => {

        /** SALVA O ID ORIGINAL DO ELEMENTO */
        var id = $(el).attr("id");

        /** DESATIVA EVENTO DE CLICK NO ELEMENTO */
        $(el).css("pointer-events", "none");

        /** Remove atributo tablename */
        var attrTablename = $(el).attr('tablename');
        if (typeof attrTablename !== 'undefined' && attrTablename !== false) {
          $(el).attr("tablename", `tablePaiFilho_${indexHistorico}`);
          $(el).attr("id", `tablePaiFilho_${indexHistorico}`);
          $(el).attr("name", `tablePaiFilho_${indexHistorico}`);
        }

        /** PASSA OS VALORES PARA OS CAMPOS E CASO SEJA CHECKBOX / RADIO SELECIONA A OPÇÃO CORRETA */
        if ($(el).attr("type") == "radio" || $(el).attr("type") == "checkbox") {
          if (valuesInputs[id]) {
            $(`#${id}`).prop("checked", true);
          } else {
            $(`#${id}`).prop("checked", false);
          }
        } else {
          $(`#${id}`).val(valuesInputs[id]);
        }

        if ($(`#${id}`).attr("type") != "zoom") {
          Util.desabilitarCampos([`#${id}`]);
        }
      });

      /** Remove atributo detailname de todas as TR's */
      $.makeArray($(`#idPainelHistorico___${indexHistorico}`).find("tr")).forEach(el => {
        $(el).removeAttr("detailname");
      });

      $(".bootstrap-tagsinput:not(.bootstrap-tagsinput-max)").each(function (key, element) {
        var a = $(element)[0].previousSibling
        $(a).show()
      });
      $(".bootstrap-tagsinput:not(.bootstrap-tagsinput-max)").hide()

      /** ALTERA CHAMADA VISUALIZAÇÃO DOS ANEXOS PARA O JSONPASTAS DO HISTÓRICO */
      let jsonPastasHist = valuesInputs[`jsonPastas___${indexHistorico}`]
      $.makeArray($(`#idPainelHistorico___${indexHistorico}`).find(`button[id^='${indexHistorico}_visualizar']`)).forEach(btn => {
        let categoria = $(btn).attr("onclick").split("'")[1]
        $(btn).attr("onclick", `formController.visualizarArquivoCategoriaHistorico('${jsonPastasHist}', '${categoria}')`)
      })

      /** RETORNA O EVENTO DE CLICK PARA BOTÕES DE VISUALIZAR ANEXO */
      $(`#idPainelHistorico___${indexHistorico}`).find("[id^='listaDocsIndicaClassi'], .btn-success").css("pointer-events", "auto");
      $(`#idPainelHistorico___${indexHistorico}`).find(".btn-success").attr("disabled", false)

    }
  }

  montaTableAnexos(idFluig) {
    var documentIds = DatasetService.getDataset("dsGetAttachments", [idFluig], null, null);

    if (documentIds) {
      if (documentIds.values.length > 0 && documentIds.values[0].documentId != "Array com dados nao informado") {
        $("#tableAnexosPedido").append("<tbody></tbody>");
        for (var i = 1; i < documentIds.values.length; i++) {


          var constraint = new Array(
            DatasetFactory.createConstraint("documentPK.documentId", documentIds.values[i].documentId, documentIds.values[i].documentId, ConstraintType.MUST)
          )
          var datasetDescription = DatasetService.getDataset("document", null, constraint, null);

          var token = {
            key: "52ad53d1-f25e-499e-874d-3468243c3d43",
            secret: "0fa077d9-a123-4fd5-a49f-71bd71a7de253a29773b-3492-4e15-b8fa-b01a76ca4355"
          };
          var consumer = {
            key: 'acesso_GET',
            secret: 'secretAcessoGETCAPUL#'
          };

          var oauth = OAuth({
            consumer: consumer,
            signature_method: 'HMAC-SHA1',
            hash_function: function (base_string, key) {
              return CryptoJS.HmacSHA1(base_string, key).toString(CryptoJS.enc.Base64);
            },
            nonce_length: 6
          });

          var request_data = {
            url: top.WCMAPI.getServerURL() + `/api/public/2.0/documents/getDownloadURL/${documentIds.values[i].documentId}`,
            method: 'GET',
          };

          $.ajax({
            url: top.WCMAPI.getServerURL() + `/api/public/2.0/documents/getDownloadURL/${documentIds.values[i].documentId}`,
            type: "GET",
            headers: oauth.toHeader(oauth.authorize(request_data, token)),
            contentType: "application/json",
            async: false,
            success: function (data) {
              $("#tableAnexosPedido").find("tbody").append(`
                    <tr>
                      <td>${datasetDescription.values[0]["documentDescription"]}</td>
                      <td>
                        <a target="_blank" href="${data.content}"><button class="btn btn-success"><i class="flaticon flaticon-file icon-sm"></i></button></a>
                      </td>
                    </tr>
                  `)
            },
            error: function (data, errorThrown, status) {
              $("#tableAnexosPedido").find("tbody").append(`
                    <tr>
                      <td>Anexo ${i}</td>
                      <td>
                        Erro ao buscar anexo;
                      </td>
                    </tr>
                  `)
            }
          });
        }
      } else {
        $("#tableAnexosPedido").closest("div").append(`<div class="col-lg-12" id="containerVazioAnexos" style="text-align: center;">
            <h4>Não há anexos nessa solicitação</h4>
          </div>`)
      }
    }
  }

  static optionFisica(text) {
    let mensagem = "";
    switch (text) {
      case "1":
        mensagem = `
            <p>Anexos Obrigatórios</p><br>
            <p>Cópia dos documentos pessoais (RG E CPF)</p><br>
            <p>Cópia do comprovante de Inscrição Estadual de Produtor Rural (caso tenha)</p>`;
        break;

      case "2":
        $("#divCredito").show();
        mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF)</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do cônjuge</p><br>
                <p>Comprovante de renda atualizado</p><br>
                <p>Cópia do comprovante de endereço para correspondência atualizado</p><br>`;
        break;
      case "3":
        mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do pretendente</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) do cônjuge</p><br>
                <p>Cópia da certidão de casamento</p><br>
                <p>Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal,
                    inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas
                    onde tenha residido nos últimos 05 (cinco) anos;
                </p><br>
                <p>Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta)
                    dias.</p><br>
                <p>Cópia do comprovante de Inscrição Estadual de Produtor Rural</p><br>
                <p>Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de
                    arrendamento rural devidamente registrado</p><br>
                <p>Cópia da declaração do ITR do exercício atual</p><br>
                <p>Cópia da ficha sanitária do rebanho atualizada</p><br>
                <p>Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias</p><br>
                <p>Comprovante de renda</p><br>`;
        break;
      default:
        mensagem = `
                <p>Preencha o tipo de cadastro</p>
                `;
    }

    return mensagem;
  }

  static optionjuridica(text) {
    let mensagem = "";
    switch (text) {
      case "1":
        mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>`;
        break;

      case "2":
        $("#divCredito").show();
        mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges</p><br>
                <p>Cópia do comprovante de endereço para correspondência atualizado</p><br>
                <p>Cópia comprovante de renda atualizado</p><br>`;
        break;

      case "3":
        mensagem = `
                <p>Anexos Obrigatórios</p><br>
                <p>Cópia do ato constitutivo da empresa (estatuto/contrato social e alterações)</p><br>
                <p>Cópia CNPJ e Inscrição Estadual</p><br>
                <p>Cópia dos documentos pessoais (RG E CPF) dos representantes legais e seus cônjuges</p><br>
                <p>Certidões negativas de Protesto, Cível e Criminal de competência estadual e federal,
                    inclusive de juizados especiais, obtida junto aos cartórios de distribuição das comarcas
                    onde tenha se estabelecido nos últimos 05 (cinco) anos
                </p><br>
                <p>Obs: As certidões descritas acima deverão ser originais e expedidas a menos de 30 (trinta)
                    dias</p><br>
                <p>Cópia da certidão do registro de imóveis da propriedade rural atualizada ou contrato de
                    arrendamento rural devidamente registrado</p><br>
                <p>Cópia da declaração do ITR do exercício atual</p><br>
                <p>Cópia da ficha sanitária do rebanho atualizada</p><br>
                <p>Cópia do comprovante de endereço para correspondência com emissão a menos de 30 dias</p><br>
                <p>Comprovante de renda</p><br>`;
        break;
      default:
        mensagem = `
                <p>Preencha o tipo de cadastro</p>
                `;
    }

    return mensagem;
  }

}